#
# AC 07/12/2017
#
# update an already existing SVN with sub-directories 
# should be run at top of the root of the CVS (e.g. gdl/)
#
cd gdl
svn update
cd ..
#

