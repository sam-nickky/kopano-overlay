#
# AC 07/12/2017
# create a copy of the current status of the SVN from nothing
# only the trunk ! in a gdl/ directory
#
svn checkout https://svn.code.sf.net/p/gnudatalanguage/svn/trunk/gdl
