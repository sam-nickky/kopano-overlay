
some informations about these files and this directory

1/ procedures from the IDL library

Most of the files here are re-implementation of the
open source files available in the IDL lib directory.
Since the original library is under Copyright, we cannot copy it
directly in GDL. Then we need to develop a clone for some of the 
most useful procedures in this library.

Some of these routines can be found and downloaded from
http://idlastro.gsfc.nasa.gov/idllibsrch.html
but we cannot include them now in GDL.

Please see STATUS for a list of the files,
if they are needed, or not, written (in GDL or C++)
with perfect clone or less perfect

Please see UrgentNeed.txt for the most urgent needed procedures.
You can notify me (at : alaingdl AT users.sourceforge.net )
if you start to work on one of these procedures.
I can help you to put them in the CVS.

2/ Other files

some other files are put here, which are not in the IDL lib. path,
but correspond to procedures available in IDL, in binary (executable
build in) form. Here they are re-implemented in GDL langage.

e.g.:
save.pro
restore.pro
read_jpeg.pro
read_png.pro
write_jpeg.pro
write_png.pro
file_lines.pro
tvscl.pro
smooth.pro

