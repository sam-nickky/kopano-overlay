def py_print(a):
    print a

    
